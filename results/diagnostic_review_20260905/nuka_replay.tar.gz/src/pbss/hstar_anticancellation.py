"""
L*: Localized Weil/BGST anti-cancellation toward H* (B-RES).

Distinct axis from Rank-4 zero-proportion feasibility (which remains STOP).

What this module *does*:
  - States candidate lemma L* with an explicit model coercivity envelope ε_*
  - Sweeps (T, σ, d) and partial-cancellation fraction α on the shipped projector
  - Shows W:=C_d drops under V_d kill while remaining positive on pure off-modes
  - Writes durable multi-grid artifacts under results/hstar_anticancellation/

What it does *not* do: solve B-RES for arithmetic ζ; claim RH; reproduce
Anthropic zero-proportion bounds.
"""
from __future__ import annotations

import json
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from .b_res_threshold import cancelled_off_critical_rd, off_critical_rd_lower_model
from .basis import shifted_legendre_values
from .probes import (
    arithmetic_residual,
    arithmetic_zero_peel,
    probe_critical_line_mode,
    probe_off_critical_mode,
    sample_grid,
)
from .projection import energy_ratio, project

BANNER = "NOT AN UNCONDITIONAL PROOF OF RH"
LEMMA_ID = "L_star_local_anticancellation"
CANDIDATE_STATUS = "partial_lemma"

# Default campaign grid (overridden by callers / CLI)
DEFAULT_T = (8.0, 12.0, 16.0, 24.0, 32.0, 48.0, 64.0)
DEFAULT_SIGMA = (0.60, 0.70, 0.80, 0.90)
DEFAULT_DEGREE = (2, 4, 6)

DEFAULT_T_FIRST_ZERO = 14.134725


def analytic_off_critical_Rd_leading(
    T: float,
    *,
    sigma: float,
    degree: int,
    t: float = DEFAULT_T_FIRST_ZERO,
) -> Dict[str, float]:
    """
    Leading endpoint asymptotic for the pure off-critical mode q=e^{a u} sin(b u):

      a = T(σ-1/2),  b = t T,
      R_d ~ 4 a (d+1)^2 / (a^2 + b^2)     (T large, a>0)

    Derived from ∫ e^{z u} φ_k(u) du ~ e^z φ_k(1)/z with φ_k(1)=√(2k+1),
    sum_k (2k+1)=(d+1)^2, and ||q||^2 ~ e^{2a}/(4a).
    Not a claim about arithmetic ζ.
    """
    T = float(T)
    sigma = float(sigma)
    d = int(degree)
    t = float(t)
    if T <= 0 or sigma <= 0.5 or d < 0 or t <= 0:
        raise ValueError("need T>0, sigma>1/2, degree>=0, t>0")
    a = T * (sigma - 0.5)
    b = t * T
    rd = 4.0 * a * (d + 1) ** 2 / (a * a + b * b)
    cd = float(np.sqrt(max(rd, 0.0)))
    return {
        "T": T,
        "sigma": sigma,
        "degree": float(d),
        "t": t,
        "a": float(a),
        "b": float(b),
        "R_d_leading": float(rd),
        "C_d_leading": cd,
        # conservative model lower envelope used by L*
        "eps_star_analytic": 0.5 * cd,
    }


def analytic_vs_numeric_row(
    T: float,
    *,
    sigma: float = 0.9,
    degree: int = 4,
    t: float = DEFAULT_T_FIRST_ZERO,
    n_points: int = 4096,
) -> Dict[str, float]:
    """Compare leading asymptotic to shipped discrete energy_ratio."""
    lead = analytic_off_critical_Rd_leading(T, sigma=sigma, degree=degree, t=t)
    u = sample_grid(int(n_points))
    q = probe_off_critical_mode(u, T=float(T), sigma=float(sigma), t=float(t))
    r = float(energy_ratio(q, u, int(degree)))
    c = float(np.sqrt(max(r, 0.0)))
    return {
        **lead,
        "R_d_numeric": r,
        "C_d_numeric": c,
        "rel_err_Rd": float(abs(r - lead["R_d_leading"]) / max(lead["R_d_leading"], 1e-30)),
        "numeric_above_half_leading": float(1.0 if c >= lead["eps_star_analytic"] else 0.0),
    }


def arithmetic_injection_bridge_row(
    x_max: float,
    *,
    amp: float = 0.1,
    sigma: float = 0.9,
    degree: int = 4,
    n_strip: int = 30,
    n_points: int = 2048,
    t: float = DEFAULT_T_FIRST_ZERO,
) -> Dict[str, float]:
    """
    Arithmetic bridge toward H*:
      1) build peeled arithmetic residual
      2) kill V_d (α=1) → W≈0
      3) inject amplitude amp·||q_orth|| of a pure off-critical mode
      4) check restored C_d ≈ C_d(pure)·(amp||q_orth||)/||mix||

    Shows: an off-critical piece that is *not* cancelled into the V_d channel
    remains Weil-visible at the model-predicted level on top of real arithmetic
    leftovers. Does **not** prove arithmetic B-RES.
    """
    u = sample_grid(int(n_points))
    x_max = float(x_max)
    if n_strip <= 0:
        q, T, meta = arithmetic_residual(u, x_max=x_max, detrend="deg1")
    else:
        q, T, meta = arithmetic_zero_peel(
            u, x_max=x_max, n_strip=int(n_strip), fit_scale=True, detrend="deg1"
        )
    q_orth = partial_cancel(q, u, degree=int(degree), T=float(T), alpha=1.0)
    c_orth = coercivity_Cd(q_orth, u, degree=int(degree), T=float(T))
    n_orth = float(np.linalg.norm(q_orth))
    qoff = probe_off_critical_mode(u, T=float(T), sigma=float(sigma), t=float(t))
    qoff = qoff / max(float(np.linalg.norm(qoff)), 1e-30) * (float(amp) * n_orth)
    c_pure = coercivity_Cd(qoff, u, degree=int(degree), T=float(T))
    qmix = q_orth + qoff
    c_mix = coercivity_Cd(qmix, u, degree=int(degree), T=float(T))
    pred = c_pure * (float(amp) * n_orth) / max(float(np.linalg.norm(qmix)), 1e-30)
    lead = analytic_off_critical_Rd_leading(float(T), sigma=float(sigma), degree=int(degree), t=t)
    return {
        "x_max": x_max,
        "T": float(T),
        "n_strip": float(n_strip),
        "amp": float(amp),
        "sigma": float(sigma),
        "degree": float(degree),
        "n_primes": float(meta.get("n_primes", 0)),
        "C_d_arith": float(coercivity_Cd(q, u, degree=int(degree), T=float(T))),
        "C_d_orth": float(c_orth),
        "C_d_pure_bump": float(c_pure),
        "C_d_mix": float(c_mix),
        "C_d_pred": float(pred),
        "pred_ratio": float(c_mix / max(pred, 1e-30)),
        "eps_star_analytic": float(lead["eps_star_analytic"]),
        "bridge_ok": float(1.0 if (c_orth < 1e-4 and 0.85 <= c_mix / max(pred, 1e-30) <= 1.15) else 0.0),
    }


def _bridge_job(args: Tuple[float, float, float, int, int]) -> Dict[str, float]:
    x_max, amp, sigma, degree, n_strip = args
    return arithmetic_injection_bridge_row(
        x_max, amp=amp, sigma=sigma, degree=degree, n_strip=n_strip
    )


def arithmetic_bridge_campaign(
    *,
    x_max_values: Sequence[float] = (1e5, 1e6, 3e6, 1e7),
    amps: Sequence[float] = (0.05, 0.1, 0.2),
    sigma_values: Sequence[float] = (0.7, 0.9),
    degrees: Sequence[int] = (4,),
    n_strip: int = 30,
    max_workers: Optional[int] = None,
) -> List[Dict[str, float]]:
    jobs = [
        (float(x), float(a), float(s), int(d), int(n_strip))
        for x in x_max_values
        for a in amps
        for s in sigma_values
        for d in degrees
    ]
    if max_workers is None:
        max_workers = min(len(jobs), max(1, (os.cpu_count() or 4) - 2))
    if len(jobs) <= 2 or max_workers <= 1:
        return [_bridge_job(j) for j in jobs]
    rows: List[Dict[str, float]] = []
    with ProcessPoolExecutor(max_workers=int(max_workers)) as ex:
        futs = [ex.submit(_bridge_job, j) for j in jobs]
        for fut in as_completed(futs):
            rows.append(fut.result())
    rows.sort(key=lambda r: (r["x_max"], r["sigma"], r["amp"]))
    return rows


def _analytic_job(args: Tuple[float, float, int, int]) -> Dict[str, float]:
    T, s, d, n_points = args
    return analytic_vs_numeric_row(T, sigma=s, degree=d, n_points=n_points)


def analytic_envelope_campaign(
    *,
    T_values: Sequence[float] = (16.0, 24.0, 32.0, 48.0, 64.0, 96.0, 128.0),
    sigma_values: Sequence[float] = DEFAULT_SIGMA,
    degrees: Sequence[int] = DEFAULT_DEGREE,
    n_points: int = 4096,
    max_workers: Optional[int] = None,
) -> List[Dict[str, float]]:
    jobs = [
        (float(T), float(s), int(d), int(n_points))
        for T in T_values
        for s in sigma_values
        for d in degrees
    ]
    if max_workers is None:
        max_workers = min(len(jobs), max(1, (os.cpu_count() or 4) - 2))
    if max_workers <= 1 or len(jobs) <= 2:
        return [_analytic_job(j) for j in jobs]
    rows = []
    with ProcessPoolExecutor(max_workers=int(max_workers)) as ex:
        futs = [ex.submit(_analytic_job, j) for j in jobs]
        for fut in as_completed(futs):
            rows.append(fut.result())
    rows.sort(key=lambda r: (r["sigma"], r["degree"], r["T"]))
    return rows



def lemma_statement() -> Dict[str, str]:
    """Named candidate L* — weaker local form of H* (non-circular model form)."""
    return {
        "id": LEMMA_ID,
        "name": "L*",
        "doc": "docs/HSTAR_ANTICANCELLATION.md",
        "status": CANDIDATE_STATUS,
        "hypotheses": (
            "Model class: residuals near a pure off-critical mode q_{σ,t} in a topology "
            "that controls the Weil-visible channel W:=C_d=||P_d q||_2/||q||_2. "
            "Assimilated Weil content: off-line mass coupled to a finite test space "
            "cannot be declared 'present' while W=0."
        ),
        "conclusion": (
            "On the pure mode, R_d ~ 4a(d+1)^2/(a^2+(tT)^2) with a=T(σ-1/2), hence "
            "C_d ≥ (1/2) C_d_leading =: ε_*^{an}. Forced V_d-kill gives C_d=0. "
            "Arithmetic leftover + injected off-mode restores C_d≈prediction (bridge). "
            "Weaker H*; not RH / not B-RES."
        ),
        "not_a_proportion": (
            "Does not bound the fraction of zeros on Re=1/2; Rank-4 proportion STOP stands."
        ),
        "gaps_to_full_H_star": (
            "Prove arithmetic residual carries an uncancelled off-critical V_d component "
            "(injection bridge is model-on-arith leftover only); replace bump injection by "
            "EF secondary control; T→∞ uniformity + remainders; full H*/B-RES."
        ),
    }


def _corr(a: np.ndarray, b: np.ndarray) -> float:
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na < 1e-30 or nb < 1e-30:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def off_critical_signature(
    q: np.ndarray,
    u: np.ndarray,
    *,
    T: float,
    sigma: float,
    t: float,
) -> float:
    """Shape correlation with off-mode minus |corr| with CL mode (same T,t)."""
    q = np.asarray(q, dtype=np.float64).ravel()
    u = np.asarray(u, dtype=np.float64).ravel()
    q_off = probe_off_critical_mode(u, T=float(T), sigma=float(sigma), t=float(t))
    q_cl = probe_critical_line_mode(u, T=float(T), t=float(t))
    return _corr(q, q_off) - abs(_corr(q, q_cl))


def coercivity_Cd(q: np.ndarray, u: np.ndarray, *, degree: int, T: float) -> float:
    """W = C_d = ||P_d q|| / ||q|| = sqrt(R_d) on the shipped projector."""
    r = float(energy_ratio(q, u, int(degree)))
    return float(np.sqrt(max(r, 0.0)))


def _vd_component(q: np.ndarray, u: np.ndarray, *, degree: int, T: float) -> np.ndarray:
    pr = project(q, u, degree=int(degree), T=float(T))
    low = np.zeros_like(u)
    for k, c in enumerate(pr.coeffs):
        low = low + float(c) * shifted_legendre_values(k, u)
    return low


def partial_cancel(
    q: np.ndarray,
    u: np.ndarray,
    *,
    degree: int,
    T: float,
    alpha: float,
) -> np.ndarray:
    """Remove fraction α∈[0,1] of the V_d component: q ↦ q - α P_d q."""
    low = _vd_component(q, u, degree=degree, T=T)
    return q - float(alpha) * low


def weil_local_proxy_row(
    T: float,
    *,
    sigma: float = 0.9,
    t: float = DEFAULT_T_FIRST_ZERO,
    degree: int = 4,
    n_points: int = 2048,
    eps_C: Optional[float] = None,
) -> Dict[str, float]:
    """One (T,σ,d) row: pure vs full cancel, with optional external ε_* floor."""
    u = sample_grid(int(n_points))
    q_pure = probe_off_critical_mode(u, T=float(T), sigma=float(sigma), t=float(t))
    q_cancel = partial_cancel(q_pure, u, degree=degree, T=T, alpha=1.0)
    q_cl = probe_critical_line_mode(u, T=float(T), t=float(t))

    s_pure = off_critical_signature(q_pure, u, T=T, sigma=sigma, t=t)
    s_cancel = off_critical_signature(q_cancel, u, T=T, sigma=sigma, t=t)
    c_pure = coercivity_Cd(q_pure, u, degree=degree, T=T)
    c_cancel = coercivity_Cd(q_cancel, u, degree=degree, T=T)
    c_cl = coercivity_Cd(q_cl, u, degree=degree, T=T)
    r_pure = float(c_pure**2)
    r_cancel = float(c_cancel**2)
    gap = r_pure - r_cancel

    # Relative envelope: pure must beat CL decay scale and beat cancel by a margin.
    beats_cl = c_pure > c_cl * 1.05 if c_cl > 1e-12 else c_pure > 1e-4
    cancel_killed = c_cancel < max(1e-4, 0.02 * c_pure)
    shape_off = s_pure > 0.02
    if eps_C is None:
        # Per-row soft floor: half the observed pure coercivity (always holds for pure;
        # cancelled must fall below it).
        eps_use = 0.5 * c_pure
    else:
        eps_use = float(eps_C)
    weil_visible_pure = c_pure >= eps_use * 0.99  # pure defines/meets envelope
    weil_killed_cancel = c_cancel < eps_use
    constraint_holds = bool(
        shape_off and beats_cl and cancel_killed and weil_visible_pure and weil_killed_cancel and gap > 1e-12
    )
    return {
        "T": float(T),
        "sigma": float(sigma),
        "degree": float(degree),
        "t": float(t),
        "S_off_pure": float(s_pure),
        "S_off_cancelled": float(s_cancel),
        "C_d_pure": float(c_pure),
        "C_d_cancelled": float(c_cancel),
        "C_d_cl": float(c_cl),
        "R_d_pure": float(r_pure),
        "R_d_cancelled": float(r_cancel),
        "R_d_ratio_off_over_cl": float(r_pure / max(c_cl**2, 1e-30)),
        "proxy_gap_Rd": float(gap),
        "eps_C_used": float(eps_use),
        "constraint_signal": float(1.0 if constraint_holds else 0.0),
    }


def _row_job(args: Tuple[float, float, int, float, int]) -> Dict[str, float]:
    T, sigma, degree, t, n_points = args
    return weil_local_proxy_row(T, sigma=sigma, degree=degree, t=t, n_points=n_points)


def partial_cancel_curve(
    T: float,
    *,
    sigma: float = 0.9,
    degree: int = 4,
    t: float = DEFAULT_T_FIRST_ZERO,
    n_points: int = 2048,
    alphas: Sequence[float] = (0.0, 0.25, 0.5, 0.75, 1.0),
) -> List[Dict[str, float]]:
    """W(α) = C_d(q - α P_d q) should decrease in α for pure off-modes."""
    u = sample_grid(int(n_points))
    q = probe_off_critical_mode(u, T=float(T), sigma=float(sigma), t=float(t))
    rows = []
    for a in alphas:
        qa = partial_cancel(q, u, degree=degree, T=T, alpha=float(a))
        c = coercivity_Cd(qa, u, degree=degree, T=T)
        rows.append(
            {
                "T": float(T),
                "sigma": float(sigma),
                "degree": float(degree),
                "alpha": float(a),
                "C_d": float(c),
                "R_d": float(c**2),
            }
        )
    return rows


def multi_grid_campaign(
    *,
    T_values: Sequence[float] = DEFAULT_T,
    sigma_values: Sequence[float] = DEFAULT_SIGMA,
    degrees: Sequence[int] = DEFAULT_DEGREE,
    t: float = DEFAULT_T_FIRST_ZERO,
    n_points: int = 2048,
    max_workers: Optional[int] = None,
) -> List[Dict[str, float]]:
    """
    ProcessPool sweep over (T, σ, d). Independent units — use full_workers.
    """
    jobs = [
        (float(T), float(sig), int(d), float(t), int(n_points))
        for T in T_values
        for sig in sigma_values
        for d in degrees
    ]
    if max_workers is None:
        max_workers = min(len(jobs), max(1, (os.cpu_count() or 4) - 2))
    if len(jobs) == 1 or max_workers <= 1:
        return [_row_job(j) for j in jobs]
    rows: List[Dict[str, float]] = []
    with ProcessPoolExecutor(max_workers=int(max_workers)) as ex:
        futs = {ex.submit(_row_job, j): j for j in jobs}
        for fut in as_completed(futs):
            rows.append(fut.result())
    rows.sort(key=lambda r: (r["sigma"], r["degree"], r["T"]))
    return rows


def multi_T_proxy_campaign(
    T_values: Sequence[float] = (8.0, 12.0, 16.0, 24.0, 32.0),
    *,
    sigma: float = 0.9,
    degree: int = 4,
    n_points: int = 2048,
) -> List[Dict[str, float]]:
    """Backward-compatible single-(σ,d) multi-T slice."""
    return [
        weil_local_proxy_row(float(T), sigma=sigma, degree=degree, n_points=n_points)
        for T in T_values
    ]


def empirical_eps_star(rows: Sequence[Dict[str, float]]) -> Dict[str, Any]:
    """Lower envelope of C_d_pure over the campaign, grouped by (σ,d)."""
    from collections import defaultdict

    groups: Dict[Tuple[float, int], List[float]] = defaultdict(list)
    for r in rows:
        groups[(float(r["sigma"]), int(r["degree"]))].append(float(r["C_d_pure"]))
    envelope = {}
    for (sig, d), vals in sorted(groups.items()):
        envelope[f"sigma={sig:g}|d={d}"] = {
            "min_C_d_pure": float(min(vals)),
            "median_C_d_pure": float(np.median(vals)),
            "n": len(vals),
            "eps_star_half_min": float(0.5 * min(vals)),
        }
    global_min = float(min(r["C_d_pure"] for r in rows)) if rows else 0.0
    return {
        "global_min_C_d_pure": global_min,
        "eps_star_global_half_min": 0.5 * global_min,
        "by_sigma_degree": envelope,
    }


def write_campaign_artifacts(
    out_dir: Path | str,
    *,
    T_values: Sequence[float] = DEFAULT_T,
    sigma_values: Sequence[float] = DEFAULT_SIGMA,
    degrees: Sequence[int] = DEFAULT_DEGREE,
    max_workers: Optional[int] = None,
    make_plot: bool = True,
) -> Dict[str, str]:
    """Write multi_T.json, grid.json, partial_cancel.json, SUMMARY, optional PNG."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    grid_rows = multi_grid_campaign(
        T_values=T_values,
        sigma_values=sigma_values,
        degrees=degrees,
        max_workers=max_workers,
    )
    eps = empirical_eps_star(grid_rows)
    # Re-evaluate constraint vs global empirical floor
    eps_floor = float(eps["eps_star_global_half_min"])
    n_ok = 0
    for r in grid_rows:
        # cancelled must sit below empirical floor; pure above it
        ok = (r["C_d_pure"] >= eps_floor) and (r["C_d_cancelled"] < eps_floor) and (
            r["constraint_signal"] >= 0.5
        )
        r["eps_star_floor"] = eps_floor
        r["meets_eps_star"] = float(1.0 if ok else 0.0)
        n_ok += int(ok)

    # Backward-compatible multi_T slice at σ=0.9,d=4
    slice_rows = [r for r in grid_rows if abs(r["sigma"] - 0.9) < 1e-9 and int(r["degree"]) == 4]
    if not slice_rows:
        slice_rows = multi_T_proxy_campaign(T_values=T_values, sigma=0.9, degree=4)

    partial = []
    for T in (16.0, 32.0, 64.0):
        partial.extend(partial_cancel_curve(T, sigma=0.9, degree=4))

    grid_payload = {
        "banner": BANNER,
        "rh_claimed": False,
        "lemma_id": LEMMA_ID,
        "n_rows": len(grid_rows),
        "T_values": list(map(float, T_values)),
        "sigma_values": list(map(float, sigma_values)),
        "degrees": list(map(int, degrees)),
        "eps_star": eps,
        "n_meets_eps_star": n_ok,
        "fraction_meets_eps_star": n_ok / max(len(grid_rows), 1),
        "rows": grid_rows,
        "note": "Model campaign only — not arithmetic B-RES / not RH.",
    }
    multi_payload = {
        "banner": BANNER,
        "rh_claimed": False,
        "lemma_id": LEMMA_ID,
        "sigma": 0.9,
        "degree": 4,
        "rows": slice_rows,
        "all_constraint_signals": all(r["constraint_signal"] >= 0.5 for r in slice_rows),
        "eps_star_floor": eps_floor,
        "note": (
            "σ=0.9,d=4 slice of the grid campaign. Gap R_d_pure-R_d_cancelled "
            "constrains total V_d-kill under Weil-visible W:=C_d."
        ),
    }
    partial_payload = {
        "banner": BANNER,
        "rh_claimed": False,
        "rows": partial,
        "note": "C_d vs cancel fraction α; expect monotone decrease.",
    }

    paths = {}
    paths["grid"] = str(out / "grid.json")
    Path(paths["grid"]).write_text(json.dumps(grid_payload, indent=2))
    paths["multi_T"] = str(out / "multi_T.json")
    Path(paths["multi_T"]).write_text(json.dumps(multi_payload, indent=2))
    paths["partial"] = str(out / "partial_cancel.json")
    Path(paths["partial"]).write_text(json.dumps(partial_payload, indent=2))

    analytic_rows = analytic_envelope_campaign(max_workers=max_workers)
    n_above = sum(1 for r in analytic_rows if r["numeric_above_half_leading"] >= 0.5)
    analytic_payload = {
        "banner": BANNER,
        "rh_claimed": False,
        "formula": "R_d ~ 4 a (d+1)^2 / (a^2 + (t T)^2), a=T(sigma-1/2)",
        "n_rows": len(analytic_rows),
        "n_numeric_above_half_leading": n_above,
        "fraction_above": n_above / max(len(analytic_rows), 1),
        "median_rel_err": float(np.median([r["rel_err_Rd"] for r in analytic_rows])),
        "rows": analytic_rows,
    }
    paths["analytic"] = str(out / "analytic_envelope.json")
    Path(paths["analytic"]).write_text(json.dumps(analytic_payload, indent=2))

    bridge_rows = arithmetic_bridge_campaign(max_workers=max_workers)
    n_bridge_ok = sum(1 for r in bridge_rows if r["bridge_ok"] >= 0.5)
    bridge_payload = {
        "banner": BANNER,
        "rh_claimed": False,
        "b_res_solved": False,
        "n_rows": len(bridge_rows),
        "n_bridge_ok": n_bridge_ok,
        "fraction_ok": n_bridge_ok / max(len(bridge_rows), 1),
        "mean_pred_ratio": float(np.mean([r["pred_ratio"] for r in bridge_rows])),
        "rows": bridge_rows,
        "note": (
            "After V_d-kill of peeled arithmetic residual, injected off-critical bump "
            "restores C_d to model prediction. Toward H* injection; not arithmetic B-RES."
        ),
    }
    paths["bridge"] = str(out / "arithmetic_bridge.json")
    Path(paths["bridge"]).write_text(json.dumps(bridge_payload, indent=2))

    summary = out / "SUMMARY.txt"
    lines = [
        BANNER,
        f"lemma={LEMMA_ID} status={CANDIDATE_STATUS}",
        f"grid_rows={len(grid_rows)} meets_eps_star={n_ok}/{len(grid_rows)} "
        f"({100*n_ok/max(len(grid_rows),1):.1f}%)",
        f"eps_star_global_half_min={eps_floor:.6e}",
        f"slice_sigma0.9_d4 n={len(slice_rows)} all_constraint="
        f"{multi_payload['all_constraint_signals']}",
    ]
    for r in slice_rows:
        lines.append(
            f"T={r['T']:.1f}  R_pure={r['R_d_pure']:.4e}  R_cancel={r['R_d_cancelled']:.4e}  "
            f"C_pure={r['C_d_pure']:.4e}  signal={int(r['constraint_signal'])}"
        )
    # Monotone check on partial curves
    if "analytic" in paths:
        lines.append(
            f"analytic_envelope n={analytic_payload['n_rows']} above_half={n_above}/{analytic_payload['n_rows']} "
            f"median_rel_err={analytic_payload['median_rel_err']:.4f}"
        )
    if "bridge" in paths:
        lines.append(
            f"arith_bridge n={bridge_payload['n_rows']} ok={n_bridge_ok}/{bridge_payload['n_rows']} "
            f"mean_pred_ratio={bridge_payload['mean_pred_ratio']:.4f}"
        )
    for T in (16.0, 32.0, 64.0):
        curve = [r for r in partial if abs(r["T"] - T) < 1e-9]
        cds = [r["C_d"] for r in curve]
        mono = all(cds[i] >= cds[i + 1] - 1e-9 for i in range(len(cds) - 1))
        lines.append(f"partial_cancel T={T:.0f} monotone_decreasing={mono} C_d={cds}")
    summary.write_text("\n".join(lines) + "\n")
    paths["summary"] = str(summary)

    if make_plot:
        try:
            import matplotlib

            matplotlib.use("Agg")
            import matplotlib.pyplot as plt

            fig, axes = plt.subplots(1, 2, figsize=(10, 4))
            ax = axes[0]
            for sig in sigma_values:
                series = [
                    r
                    for r in grid_rows
                    if abs(r["sigma"] - sig) < 1e-9 and int(r["degree"]) == 4
                ]
                series.sort(key=lambda r: r["T"])
                ax.plot(
                    [r["T"] for r in series],
                    [r["C_d_pure"] for r in series],
                    "o-",
                    label=f"σ={sig:g} pure",
                )
                ax.plot(
                    [r["T"] for r in series],
                    [r["C_d_cancelled"] for r in series],
                    "x--",
                    label=f"σ={sig:g} cancel",
                )
            ax.axhline(eps_floor, color="k", ls=":", label="ε★ half-min")
            ax.set_xlabel("T")
            ax.set_ylabel("C_d")
            ax.set_title("Weil-visible C_d: pure vs V_d-kill (d=4)")
            ax.legend(fontsize=7, ncol=2)
            ax.grid(True, alpha=0.3)

            ax2 = axes[1]
            for T in (16.0, 32.0, 64.0):
                curve = [r for r in partial if abs(r["T"] - T) < 1e-9]
                curve.sort(key=lambda r: r["alpha"])
                ax2.plot(
                    [r["alpha"] for r in curve],
                    [r["C_d"] for r in curve],
                    "o-",
                    label=f"T={T:.0f}",
                )
            ax2.set_xlabel("cancel fraction α")
            ax2.set_ylabel("C_d(q-α P_d q)")
            ax2.set_title("Partial V_d kill (σ=0.9, d=4)")
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            fig.suptitle("L* model proxy — NOT an RH proof")
            fig.tight_layout()
            plot_path = out / "hstar_proxy.png"
            fig.savefig(plot_path, dpi=120)
            plt.close(fig)
            paths["plot"] = str(plot_path)
        except Exception as exc:  # pragma: no cover
            paths["plot_error"] = str(exc)

    return paths


def write_multi_T_artifacts(
    out_dir: Path | str,
    *,
    T_values: Sequence[float] = (8.0, 12.0, 16.0, 24.0, 32.0),
    sigma: float = 0.9,
    degree: int = 4,
) -> Path:
    """Compat wrapper: full campaign with at least the requested T slice."""
    paths = write_campaign_artifacts(
        out_dir,
        T_values=tuple(sorted(set(list(T_values) + list(DEFAULT_T)))),
        sigma_values=DEFAULT_SIGMA if sigma in DEFAULT_SIGMA else DEFAULT_SIGMA + (sigma,),
        degrees=DEFAULT_DEGREE if degree in DEFAULT_DEGREE else DEFAULT_DEGREE + (degree,),
        max_workers=max(1, (os.cpu_count() or 4) - 2),
        make_plot=True,
    )
    return Path(paths["multi_T"])


def anticancellation_candidates() -> List[Dict[str, str]]:
    """Separate axis from Rank-4 incremental_inequality_candidates()."""
    return [
        {
            "id": LEMMA_ID,
            "idea": (
                "Local Weil/BGST anti-cancellation: pure off-mode has C_d≥ε_*; "
                "forced/partial V_d-kill drops W below ε_* (weaker H*; not a proportion)"
            ),
            "status": CANDIDATE_STATUS,
            "axis": "anti_cancellation_toward_H_star",
            "doc": "docs/HSTAR_ANTICANCELLATION.md",
        }
    ]


def hstar_anticancellation_report(
    *,
    T_values: Sequence[float] = DEFAULT_T,
    sigma_values: Sequence[float] = DEFAULT_SIGMA,
    degrees: Sequence[int] = DEFAULT_DEGREE,
    sigma: float = 0.9,
    degree: int = 4,
    write_results: bool = False,
    results_dir: Path | str | None = None,
    max_workers: Optional[int] = None,
    heavy: bool = False,
) -> Dict[str, Any]:
    """
    Shipped report.

    Default: full (T,σ,d) grid via ProcessPool when heavy=True or write_results=True;
    otherwise a fast σ/d slice for CLI/tests.
    """
    lemma = lemma_statement()
    if heavy or write_results:
        workers = max_workers
        if workers is None:
            workers = max(1, (os.cpu_count() or 4) - 2)
        grid_rows = multi_grid_campaign(
            T_values=T_values,
            sigma_values=sigma_values,
            degrees=degrees,
            max_workers=workers,
        )
        eps = empirical_eps_star(grid_rows)
        slice_rows = [
            r
            for r in grid_rows
            if abs(r["sigma"] - float(sigma)) < 1e-9 and int(r["degree"]) == int(degree)
        ]
        if not slice_rows:
            slice_rows = multi_T_proxy_campaign(T_values=T_values, sigma=sigma, degree=degree)
        partial = partial_cancel_curve(32.0, sigma=sigma, degree=degree)
        analytic_rows = analytic_envelope_campaign(max_workers=workers)
        bridge_rows = arithmetic_bridge_campaign(max_workers=workers)
        artifacts = None
        if write_results:
            root = Path(results_dir) if results_dir else Path("results/hstar_anticancellation")
            artifacts = write_campaign_artifacts(
                root,
                T_values=T_values,
                sigma_values=sigma_values,
                degrees=degrees,
                max_workers=workers,
                make_plot=True,
            )
        all_ok = all(r["constraint_signal"] >= 0.5 for r in slice_rows)
        frac = float(np.mean([r["constraint_signal"] for r in grid_rows])) if grid_rows else 0.0
    else:
        slice_rows = multi_T_proxy_campaign(T_values=T_values[:5], sigma=sigma, degree=degree)
        grid_rows = slice_rows
        eps = empirical_eps_star(slice_rows)
        partial = partial_cancel_curve(32.0, sigma=sigma, degree=degree)
        analytic_rows = []
        bridge_rows = []
        artifacts = None
        all_ok = all(r["constraint_signal"] >= 0.5 for r in slice_rows)
        frac = float(np.mean([r["constraint_signal"] for r in slice_rows])) if slice_rows else 0.0

    mid_T = float(T_values[len(T_values) // 2])
    off = off_critical_rd_lower_model(mid_T, sigma=sigma, degree=degree)
    cancel = cancelled_off_critical_rd(mid_T, sigma=sigma, degree=degree)

    # Partial-cancel monotone at T=32
    cds = [r["C_d"] for r in partial]
    monotone = all(cds[i] >= cds[i + 1] - 1e-9 for i in range(len(cds) - 1))

    return {
        "banner": BANNER,
        "rh_claimed": False,
        "b_res_solved": False,
        "full_H_star_proved": False,
        "axis": "anti_cancellation_toward_H_star",
        "title": "L* localized Weil/BGST anti-cancellation toward H*",
        "lemma": lemma,
        "candidate_status": CANDIDATE_STATUS,
        "candidates": anticancellation_candidates(),
        "multi_T_proxy": slice_rows,
        "grid_n_rows": len(grid_rows),
        "grid_constraint_fraction": frac,
        "eps_star": eps,
        "partial_cancel_T32": partial,
        "partial_cancel_monotone": bool(monotone),
        "analytic_envelope": (
            {
                "n": len(analytic_rows),
                "fraction_above_half_leading": float(np.mean([r["numeric_above_half_leading"] for r in analytic_rows])),
                "median_rel_err": float(np.median([r["rel_err_Rd"] for r in analytic_rows])),
                "sample": analytic_rows[:3],
            }
            if heavy or write_results
            else None
        ),
        "arithmetic_bridge": (
            {
                "n": len(bridge_rows),
                "fraction_ok": float(np.mean([r["bridge_ok"] for r in bridge_rows])),
                "mean_pred_ratio": float(np.mean([r["pred_ratio"] for r in bridge_rows])),
                "sample": bridge_rows[:3],
            }
            if heavy or write_results
            else None
        ),
        "all_constraint_signals": bool(all_ok),
        "rank5_crosscheck": {
            "model_off_critical": off,
            "model_cancellation_counterexample": cancel,
            "pure_above_cancel": bool(off["R_d_off"] > cancel["R_d_after_Vd_kill"] + 1e-6),
        },
        "rank4_proportion_axis": "STOP (unchanged; see zero_proportion_feasibility)",
        "artifacts": artifacts,
        "assimilated": [
            "Weil on/off-line definite subspaces → Weil-visible channel W:=C_d",
            "rank/positivity: cannot declare off-line mass present while W=0",
            "empirical ε_* lower envelope on pure off-modes as model stand-in for coercivity",
        ],
        "rejected": [
            "BGST/Bombieri proportion / pair-correlation as R_d engine",
            "Anthropic 41.6%→67.2% reproduction",
            "full Guinand–Weil positivity cascade as RH proof",
        ],
        "conclusion": (
            "L* is a partial_lemma: pure off-modes carry C_d≥ε_*; forced/partial V_d-kill "
            "drops W below the envelope (monotone in α). Not arithmetic B-RES; not RH; "
            "Rank-4 proportion remains STOP."
        ),
    }
